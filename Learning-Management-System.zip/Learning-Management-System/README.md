Learning Management system

"""
Установить Anaconda

Открыть Anaconda shell, и далее следить по всему процессу что я написал снизу:

Create virtual environment by conda

```
$ conda create -n djangolms python=3.6

```
Activate virtual environment

```
$ conda activate djangolms

```
Install the dependencies

```
$ pip install -r requirements.txt
```

Finally, run the development server

```
$ python manage.py runserver
```

The project would be available at 127.0.0.1:8000

## Running the tests

Use the details below to login and access the different features and roles of the system

|   username   |  password   |       Role |
|:------------:|:-----------:|-----------:|
|  kdutchburn2 | randompass  |    Admin   |
|  bosheilds1u | randompass  |    Admin   |
| cschachter98 | randompass  |    Admin   |
| aashurst48   | randompass  | Instructor |
|   acolbyea   | randompass  | Instructor |
|   aedger6j   | randompass  | Instructor |
|   abasond5   | randompass  |   Student  |
|    aberny    | randompass  |   Student  |
|  adeverale8y | randompass  |   Student  |

login to the system using one of the login credentials in the table above


Check mylogs.txt to get proper outputs in console. Сверьтесь с моими оутпутами в консоли
